import scrapy

class RateItem(scrapy.Item):
    currency=scrapy.Field()
    rate=scrapy.Field()
