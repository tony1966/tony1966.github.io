import scrapy
from project3.items import RateItem

class RateSpider(scrapy.Spider):
    name='bot_rate_spider'
    allowed_domains=['rate.bot.com.tw']
    start_urls=['https://rate.bot.com.tw/xrt?Lang=zh-TW']

    def parse(self, response):
        xpath='//tbody/tr/td/div/div[position()=2]/text()'  
        currency=response.xpath(xpath).getall()    
        currency=[c.strip() for c in currency]       
        xpath='//tbody/tr/td[position()=3]/text()'    
        rate=response.xpath(xpath).getall()    
        rate_dict={c: r for c, r in zip(currency, rate)}
        for c, r in rate_dict.items():
            rate_item=RateItem()
            rate_item['currency']=c
            rate_item['rate']=r
            yield rate_item

