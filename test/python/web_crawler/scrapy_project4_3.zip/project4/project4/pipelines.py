from itemadapter import ItemAdapter
import sqlite3

class RemoveParentheses:
    def process_item(self, item, spider):
        currency=item['currency'].replace('(', '').replace(')', '')
        item['currency']=currency
        return item

class Save2SQLite:
    def open_spider(self, spider):
        db=spider.settings.get('SQLITE_DATABASE')
        self.conn=sqlite3.connect(db)
        self.cur=self.conn.cursor()
        SQL='CREATE TABLE if not exists bot_rate(' +\
            'currency TEXT, rate TEXT)'
        self.cur.execute(SQL)
    def process_item(self, item, spider):
        VALUES=(item['currency'], item['rate'])
        SQL='INSERT INTO bot_rate VALUES(?, ?)'
        self.cur.execute(SQL, VALUES)
        return item
    def close_spider(self, spider):
        self.conn.commit()
        self.conn.close()