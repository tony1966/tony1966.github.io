import scrapy

class RateSpider(scrapy.Spider):
    name='bot_rate_spider'
    allowed_domains=['rate.bot.com.tw']
    start_urls=['https://rate.bot.com.tw/xrt?Lang=zh-TW']

    def parse(self, response):  
        css='tbody > tr > td:first-child > div > ' +\
            'div.visible-phone.print_hide::text'  
        currency=response.css(css).getall() 
        currency=[c.strip() for c in currency]       
        css='tbody > tr > td:nth-child(3)::text'    
        rate=response.css(css).getall()    
        result={c: r for c, r in zip(currency, rate)}    
        yield result
