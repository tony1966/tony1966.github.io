from scrapy.spiders import Spider
from bs4 import BeautifulSoup

class RateSpider(Spider):
    name='project1'
    start_urls=['https://rate.bot.com.tw/xrt?Lang=zh-TW']
    def parse(self, response):
        soup=BeautifulSoup(response.text, 'html.parser')
        currency=[]
        rate=[]
        table=soup.find('table', {'title': '牌告匯率'})
        for tr in table.find('tbody').find_all('tr'):
            tds=tr.find_all('td')
            c=tds[0].find('div', {'class': 'visible-phone'}).text.strip()
            r=tds[2].text
            currency.append(c)
            rate.append(r)
        result={c: r for c, r in zip(currency, rate)}
        yield result