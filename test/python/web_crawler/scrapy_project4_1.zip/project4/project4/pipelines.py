from itemadapter import ItemAdapter

class RemoveParentheses:
    def process_item(self, item, spider):
        currency=item['currency'].replace('(', '').replace(')', '')
        item['currency']=currency
        return item
