# hello.py
def main(request, **kwargs):
    name=request.args.get('name', 'World')
    return f'Hello {name}!'