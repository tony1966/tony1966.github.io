# linebot_echo.py 
from flask import abort
from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import MessageEvent, TextMessage, TextSendMessage

def main(request, **kwargs):
    # 取得主程式讀取 .env 後以 config 字典傳遞之 LINE 權杖與金鑰
    config=kwargs.get('config', {})
    secret=config.get('LINE_CHANNEL_SECRET')
    token=config.get('LINE_CHANNEL_ACCESS_TOKEN')
    # 檢查是否有傳遞密鑰與權杖
    if not secret or not token:
        return {"error": "LINE_CHANNEL_SECRET or LINE_CHANNEL_ACCESS_TOKEN is missing"}
    # 建立呼叫 LINE API 與處理 webhook 的物件
    line_bot_api=LineBotApi(token)  # 發送回覆訊息的 API 客戶端
    handler=WebhookHandler(secret)  # 驗證簽章與分派事件的 webhook 處理器
    # 註冊 MessageEvent + TextMessage 事件的處理器
    # 注意：這段必須寫在 handler.handle() 之前, 否則事件不會被處理
    @handler.add(MessageEvent, message=TextMessage)
    def handle_message(event):
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=event.message.text)
            )
    # 取得 X-Line-Signature (用於簽章驗證) 與 request body (即使用者訊息)
    signature=request.headers.get("X-Line-Signature", "")
    body=request.get_data(as_text=True)
    # 驗證簽章是否正確, 防止偽造的請求 (確保是 LINE 平台發出的請求)
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400, "Invalid signature")
    # 處理成功回傳狀態訊息 (LINE 要求回應 HTTP 200 才視為成功)
    return {"status": "ok"}