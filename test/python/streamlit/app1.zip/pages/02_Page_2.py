# 01_Page_2.py
import streamlit as st

st.title('📄 頁面二')
st.write('這是第二頁的內容')