# 1_資料.py
import streamlit as st
import pandas as pd

st.write('這裡是資料頁面，可以顯示資料表或圖表。')
st.write(pd.DataFrame({'欄位1': [1, 2, 3], '欄位2': [4, 5, 6]}))
