# 2_關於.py
import streamlit as st

st.write('這是關於頁面，介紹應用程式的資訊。')