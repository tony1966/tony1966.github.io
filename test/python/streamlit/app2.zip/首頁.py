# 首頁.py
import streamlit as st

st.write('歡迎來到首頁！這是應用程式的起始頁面。')