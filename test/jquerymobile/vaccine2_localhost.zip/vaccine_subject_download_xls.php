<?php
//啟動 session 功能
session_start();
//設定台北時間
date_default_timezone_set("Asia/Taipei");
if (!isset($_SESSION["vaccine_admin_account"])) { //未登入回首頁
  header("Location: index.htm");
  }
//設定檔案下載標頭
header('Content-type: text/html; charset=utf-8');
header("Content-type:application/vnd.ms-excel;charset=UTF-8"); 
header("Content-Disposition:filename=vaccine.xls");
//建立 PDO 連線物件
$dsn="mysql:host=localhost;port=3306;dbname=test"; 
$username="root"; 
$password="mysql";
try {$conn=new PDO($dsn, $username, $password);}
catch (PDOException $e) {
  echo "資料庫連線錯誤!";
  die();
  }
//設定資料編碼
$conn->exec("SET CHARACTER SET utf8"); 
//讀取受試者資料表
$SQL="SELECT * FROM `vaccine` ORDER BY rdate DESC"; 
$RS=$conn->query($SQL);
$row=$RS->fetch();
echo chr(0xEF).chr(0xBB).chr(0xBF); //UTF-8 BOM
echo "序號,姓名,年齡,電話,性別,登記日期\n"; //輸出表頭
//迭代整個資料集
while(!empty($row)) {
  echo $row["id"].",".$row["name"].",".$row["age"].",".
       $row["phone"].",".$row["gender"].",".$row["rdate"]."\n";
  $row=$RS->fetch();
  }
$conn=NULL;
?>