<?php
//啟動 session 功能
session_start();
//設定台北時間
date_default_timezone_set("Asia/Taipei");
if (!isset($_SESSION["vaccine_admin_account"])) { //未登入回首頁
  header("Location: index.htm");
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <title></title>
    <meta charset="utf-8">
    <meta http-equiv="cache-control" content="no-cache">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
    <link href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" rel="stylesheet">
  </head>
  <body>
    <!-- 第一頁頁面 -->
    <section data-role="page" id="page1">
      <header data-role="header" data-position="fixed">
        <a href="vaccine_admin.php" data-role="button" data-icon="back" data-mini="true"  data-ajax="false">返回</a>
        <h1>匯出受試者資料</h1>
      </header>
      <article data-role="content">

<?php
//設定 CSV 欄位標題
$csv_header=['序號','姓名','年齡','電話','性別','登記日期'];  //CSV 欄位標題
$csv_content=chr(0xEF).chr(0xBB).chr(0xBF);  //UTF-8 BOM 開頭字元 (避免亂碼)
$csv_content .= join(',',$csv_header)."\n";  //合併 BOM 開頭與欄位標題
//建立 PDO 連線物件
$dsn="mysql:host=localhost;port=3306;dbname=test"; 
$username="root"; 
$password="mysql";
try {$conn=new PDO($dsn, $username, $password);}
catch (PDOException $e) {
  echo "資料庫連線錯誤!";
  die();
  }
//設定資料編碼
$conn->exec("SET CHARACTER SET utf8"); 
//讀取受試者資料表
$SQL="SELECT * FROM `vaccine` ORDER BY rdate DESC"; 
$RS=$conn->query($SQL);
$row=$RS->fetch(); 
//迭代整個資料集
while(!empty($row)) {
  $csv_content .= $row["id"].",".$row["name"].",".$row["age"].",".
                  $row["phone"].",".$row["gender"].",".$row["rdate"]."\n";
  $row=$RS->fetch();
  }
$conn=NULL;
file_put_contents('vaccine.csv', $csv_content);
?>
        <h3>資料表匯出成功!</h3>
        <a data-role="button" href="vaccine_subject_download_csv.php" data-ajax="false">下載 vaccine.csv</a>
      </article>
      <footer data-role="footer" data-position="fixed">
        <h3>小狐狸事務所 07-1234567</h3>
      </footer>
    </section>
  </body>
</html>