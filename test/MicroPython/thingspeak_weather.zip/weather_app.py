import xtools    
import config
import time
import urequests
import ujson

def get_weather_now(country, city, api_key):
    url=f'https://api.openweathermap.org/data/2.5/weather?q={city},{country}&units=metric&lang=zh_tw&appid={api_key}'
    try:
        res=urequests.get(url)
        data=ujson.loads(res.text)
        if data['cod']==200:    # 注意是數值
            ret={'geocode': data['id'],
                 'description': data['weather'][0]['description'],
                 'temperature': data['main']['temp'],
                 'min_temperature': data['main']['temp_min'], 
                 'max_temperature': data['main']['temp_max'],
                 'pressure': data['main']['pressure'],
                 'humidity': data['main']['humidity']}
            return ret
        else:
            return None
    except Exception as e:
        return None

def main():
    thingspeak_api_key=config.THINGSPEAK_WRITE_API_KEY   
    weather_api_key=config.WEATHER_API_KEY      
    city='Kaohsiung'     
    country='TW'    
    while True:
        r=get_weather_now(country, city, weather_api_key)
        if r != None:
            temperature=r['temperature']
            humidity=r['humidity']
            pressure=r['pressure']
            url=f'https://api.thingspeak.com/update?api_key={thingspeak_api_key}&field1={temperature}&field2={humidity}&field3={pressure}'
            r=urequests.get(url)
            print(r.text)
            time.sleep(15)
        else:
            print('Fail to get weather data.')

if __name__ == '__main__':  
    main()  
      