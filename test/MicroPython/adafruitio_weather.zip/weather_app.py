import xtools    
import config
import time
import urequests
import ujson

def get_weather_now(country, city, api_key):
    url=f'https://api.openweathermap.org/data/2.5/weather?q={city},{country}&units=metric&lang=zh_tw&appid={api_key}'
    try:
        res=urequests.get(url)
        data=ujson.loads(res.text)
        if data['cod']==200:    # 注意是數值
            ret={'geocode': data['id'],
                 'description': data['weather'][0]['description'],
                 'temperature': data['main']['temp'],
                 'min_temperature': data['main']['temp_min'], 
                 'max_temperature': data['main']['temp_max'],
                 'pressure': data['main']['pressure'],
                 'humidity': data['main']['humidity']}
            return ret
        else:
            return None
    except Exception as e:
        return None

def main():
    weather_api_key=config.WEATHER_API_KEY      
    city='Kaohsiung'     
    country='TW'    
    while True:
        r=get_weather_now(country, city, weather_api_key)
        if r != None:
            AIO_KEY=config.AIO_KEY
            headers={'X-AIO-Key': AIO_KEY}
            USERNAME='yhhuang1966'            
            FEEDS=['temperature', 'humidity', 'pressure']
            for FEED in FEEDS:
                url=f'https://io.adafruit.com/api/v2/{USERNAME}/feeds/{FEED}/data'
                data={'value': r[FEED]}
                ret=urequests.post(url, headers=headers, json=data)
                print(ret.text)
                time.sleep(2)
            time.sleep(60)
        else:
            print('Fail to get weather data.')

if __name__ == '__main__':  
    main()  
      