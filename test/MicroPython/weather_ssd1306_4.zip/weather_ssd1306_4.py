import config  
import xtools   
import urequests  
import ujson
from machine import I2C, Pin
import ssd1306
import framebuf
import big_symbol
import time

def get_weather(country, city, api_key):
    url=f'https://api.openweathermap.org/data/2.5/weather?q={city},{country}&units=metric&lang=zh_tw&appid={api_key}'
    try:
        res=urequests.get(url)
        data=ujson.loads(res.text)
        if data['cod']==200:    # 注意是數值
            ret={'geocode': data['id'],
                 'icon': data['weather'][0]['icon'],
                 'temperature': data['main']['temp'],
                 'pressure': data['main']['pressure'],
                 'humidity': data['main']['humidity']}
            return ret
        else:
            return None
    except Exception as e:
        return None

ip=xtools.connect_wifi(config.SSID, config.PASSWORD)
if ip:
    # 設定氣象爬蟲參數
    weather_api_key=config.WEATHER_API_KEY
    city='Kaohsiung'   
    country='TW'
    # 建立 I2C 與 SSD1306_I2C 物件
    i2c=I2C(0, scl=Pin(22), sda=Pin(21)) # ESP32 I2C
    oled=ssd1306.SSD1306_I2C(128, 64, i2c)
    sb=big_symbol.Symbol(oled)
    while True:  # 每分鐘抓一次更新 OLED 顯示器
        data=get_weather(country, city, weather_api_key)
        if data:
            sb.clear()
            icon_file=f'/icons/{data["icon"]}.bin'
            with open(icon_file, 'rb') as f:    
                icon=f.read()
                oled.fill(0)
                fb=framebuf.FrameBuffer(bytearray(icon), 48, 48, framebuf.MVLSB)
                oled.framebuf.blit(fb, 0, 15)
            temperature=round(data["temperature"])
            sb.text(f'{temperature}c', 50, 10)
            sb.text(f'{data["humidity"]}%', 50, 28)
            sb.text(f'{data["pressure"]}hPa', 50, 46)                
            oled.show()
            oled.text(city, 0, 0, 1)
            oled.show()
        time.sleep(60)
else:
    print('無法連線 WiFi')