import config   
import xtools
import urequests   
import ujson
from machine import I2C, Pin   
import ssd1306
import time

def get_weather(country, city, api_key):
    url=f'https://api.openweathermap.org/data/2.5/weather?q={city},{country}&units=metric&lang=zh_tw&appid={api_key}'
    try:
        res=urequests.get(url)
        data=ujson.loads(res.text)
        if data['cod']==200:    # 注意是數值
            ret={'geocode': data['id'],
                 'icon': data['weather'][0]['icon'],
                 'temperature': data['main']['temp'],
                 'pressure': data['main']['pressure'],
                 'humidity': data['main']['humidity']}
            return ret
        else:
            return None
    except Exception as e:
        return None

def show_weather(oled, data):
    oled.fill(0)  # (填滿 0 熄滅畫素)
    oled.text(data['city'], 0, 0, 1)  
    oled.text(data['time'], 0, 8, 1)  
    oled.text(f"Temperature:{data['temperature']}", 0, 16, 1)    
    oled.text(f"Humidity:{data['humidity']}", 0, 24, 1)    
    oled.text(f"Pressure:{data['pressure']}", 0, 32, 1)    
    oled.show()

def main():
    # 設定氣象爬蟲參數
    weather_api_key=config.WEATHER_API_KEY
    city='Kaohsiung'   
    country='TW'
    # 建立 I2C 與 SSD1306_I2C 物件
    i2c=I2C(0, scl=Pin(22), sda=Pin(21)) # ESP32 I2C
    oled=ssd1306.SSD1306_I2C(128, 64, i2c)
    while True:  # 每分鐘抓一次更新 OLED 顯示器
        data=get_weather(country, city, weather_api_key)
        data['time']=xtools.tw_now()  # 新增或更新欄位
        data['city']=city # 新增或更新欄位
        show_weather(oled, data)
        time.sleep(60)

if __name__ == '__main__':
  main()
