# views.py of App=myapp1
from django.shortcuts import render, redirect
from myapp1.models import Members

def get_record_by_name(request, name):
    try:
        record=Members.objects.get(name=name)
        type_of_record=type(record)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())

def get_record_by_id(request, id):
    try:
        record=Members.objects.get(id=id)
        type_of_record=type(record)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())

def list_all_records(request):
    try: 
        records=Members.objects.all().order_by('-id')
    except:
        pass
    return render(request, 'list_all_records.htm', locals())

def add_record(request):
    if request.method=='POST':   # 來自表單提交
        name=request.POST['name']
        gender=request.POST['gender']
        birthday=request.POST['birthday']
        email=request.POST['email']
        phone=request.POST['phone']
        address=request.POST['address']
        record=Members.objects.create(name=name,
                                     gender=gender,
                                     birthday=birthday,
                                     email=email,
                                     phone=phone,
                                     address=address)
        record.save()
        return redirect('/myapp1/list_all_records/')
    else:   # 來自 list_all_records.htm 的新增紀錄超連結
        message='請輸入資料'
        return render(request, 'add_record.htm', locals())
        
def edit_record(request, id=None, mode=None):
    if mode=='update':  # 來自在 edit_record.htm 按送出
        record=Members.objects.get(id=id)  # id 一定有不須捕捉例外
        record.name=request.POST['name']
        record.gender=request.POST['gender']
        record.birthday=request.POST['birthday']
        record.email=request.POST['email']
        record.phone=request.POST['phone']
        record.address=request.POST['address']
        record.save()
        return redirect('/myapp1/list_all_records/')
    else: # 來自按 list_all_records.htm 中的編輯超連結:顯示編輯頁面
        try: # 防止可能來自網址列的 id 不存在
            record=Members.objects.get(id=id)
            # 轉換 birthday 的格式 (因資料表欄位為 date 型態)
            birthday=str(record.birthday)
            birthday=birthday.replace('年', '-')
            birthday=birthday.replace('月', '-')
            birthday=birthday.replace('日', '-')
            record.birthday=birthday
        except:
            message='id 不存在'
        return render(request, 'edit_record.htm', locals())
   
def delete_record(request, id=None):
    if id:  # 有傳入 id 才刪除
        try: # 防止可能來自網址列的 id 不存在
            record=Members.objects.get(id=id)  # 取得紀錄物件
            record.delete()  # 刪除紀錄
        except: # 不處理
            pass
    return redirect('/myapp1/list_all_records/')   
  