# views.py of project=mysite
from django.shortcuts import render
from datetime import datetime

def home(request):  
    now=datetime.now()       # 傳回現在日期時間
    return render(request, 'home.htm', locals())     