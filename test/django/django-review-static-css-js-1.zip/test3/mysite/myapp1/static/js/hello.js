/* hello.js */
alert("Hello!");