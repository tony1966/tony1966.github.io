# urls.py of App=myapp1
from django.urls import path
from . import views      # 匯入 App 的視圖模組

urlpatterns = [
    path('hello/<str:name>/', views.hello),  # 有參數
    path('hello/', views.hello),  # 無參數 
    path('', views.myapp1_home),  # myapp1 的根目錄請求
]