from django.contrib import admin
from myapp1.models import Members   # 匯入 Members 模型

class MembersAdmin(admin.ModelAdmin):
    list_display=('id', 'name', 'gender', 'birthday', 'email', 'phone', 'address')
    ordering=('id', )
    search_fields=('name', 'email', 'phone', 'address',)
    list_filter=('name', 'gender')

# 向 admin 註冊 Members, MembersAdmin
admin.site.register(Members, MembersAdmin)  
