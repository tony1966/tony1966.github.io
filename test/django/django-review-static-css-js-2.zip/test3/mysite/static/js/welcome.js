/* welcome.js */
alert("Welcome!");
