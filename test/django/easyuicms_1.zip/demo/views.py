# views.py of App=demo
from django.shortcuts import render
from datetime import datetime

def hello(request, name):
    now=datetime.now()
    params={'name': name, 'now': now}
    return render(request, 'hello.htm', params)
