# urls.py of App=demo
from django.urls import path
from demo import views

app_name="demo"

urlpatterns = [
    path('hello/<name>/', views.hello),
]

