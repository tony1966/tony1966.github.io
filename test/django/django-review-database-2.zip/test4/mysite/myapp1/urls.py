# urls.py of App=myapp1
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('get_record_by_name/<str:name>/', views.get_record_by_name),
    path('get_record_by_id/<int:id>/', views.get_record_by_id),
    path('list_all_records/', views.list_all_records),
]
