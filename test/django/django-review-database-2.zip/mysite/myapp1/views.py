from django.shortcuts import render
from myapp1.models import Members

def get_record_by_name(request, name):
    try:
        record=Members.objects.get(name=name)
        type_of_record=type(record)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())

def get_record_by_id(request, id):
    try:
        record=Members.objects.get(id=id)
        type_of_record=type(record)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())
