from django.shortcuts import render
from django.http import HttpResponse

def helloworld(request):   # 傳入參數為 HttpRequest 物件, 預設用 request 承接
    return HttpResponse('<b>Hello World! <i>您好</i></b>')

def myapp1_home(request):  
    return HttpResponse('<b>歡迎來到我的 App1!</b>')   