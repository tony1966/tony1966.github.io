from django.contrib import admin
from django.urls import path
from . import views

#app_name='myapp1'  # 定義此 App 名稱讓專案的 urls.py 指派

urlpatterns = [
    path('helloworld/', views.helloworld),
    path('', views.myapp1_home), 
]