from django.shortcuts import render
from django.http import HttpResponse

def home(request):  
    return HttpResponse('<b>歡迎來到我的首頁!</b>')   