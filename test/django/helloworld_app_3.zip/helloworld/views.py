from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime

def hello1(request): 
    return HttpResponse('<b>Hello World! <i>您好</i></b>')
    
def hello2(request, name):
    now=datetime.now()
    dict1={'name': name, 'now': now}
    return render(request, 'hello.htm', dict1)