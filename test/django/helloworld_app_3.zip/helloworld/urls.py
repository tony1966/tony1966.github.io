from django.urls import path
from helloworld import views

app_name="helloworld"

urlpatterns = [
    path('hello1/', views.hello1),
    path('hello2/<name>/', views.hello2),
]
