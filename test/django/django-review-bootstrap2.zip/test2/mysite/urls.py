# urls.py of project=mysite
from django.contrib import admin
from django.urls import path, include  # include() 用來含括各 App 的 urls.py
from . import views   # 專案的視圖模組

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home),   # 將網站首頁請求委派給專案的視圖模組
    path('myapp1/', include('myapp1.urls')),     # 將 URL='myapp1/' 委派給 myapp1 的 urls.py
]
