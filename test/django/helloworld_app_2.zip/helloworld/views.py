from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime

def helloworld(request): 
    return HttpResponse('<b>Hello World! <i>您好</i></b>')
    
def hello(request, name):
    now=datetime.now()
    dict1={'name': name, 'now': now}
    return render(request, 'hello.htm', dict1)