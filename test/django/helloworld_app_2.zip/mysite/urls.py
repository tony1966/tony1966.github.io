from django.contrib import admin
from django.urls import path
from helloworld.views import helloworld, hello

urlpatterns = [
    path('admin/', admin.site.urls),
    path('helloworld/', helloworld),
    path('hello/<name>/', hello),
]
