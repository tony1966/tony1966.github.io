# views.py of App=myapp1
from django.shortcuts import render
from datetime import datetime

def hello(request, name='匿名'):   # URL='myapp1/hello/' 的處理函式
    now=datetime.now()       # 傳回現在日期時間
    return render(request, 'hello.htm', locals())

def myapp1_home(request):    # App 根目錄 URL= 'myapp1/' 的處理函式
    return render(request, 'myapp1_home.htm')   