# views.py of App=myapp1
from django.shortcuts import render, redirect
from myapp1.models import Members
from myapp1.forms import MembersForm
import re

def get_record_by_name(request, name):
    try:
        record=Members.objects.get(name=name)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())

def get_record_by_id(request, id):
    try:
        record=Members.objects.get(id=id)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())

def list_all_records(request):
    try: 
        records=Members.objects.all().order_by('-id')
    except:
        pass
    return render(request, 'list_all_records.htm', locals())

def add_record(request):
    f=MembersForm()   # 建立空表單物件 (未綁定)
    if request.method=='POST':   # 來自表單提交
        name=request.POST['name']
        gender=request.POST['gender']
        birthday=request.POST['birthday']
        email=request.POST['email']
        phone=request.POST['phone']
        address=request.POST['address']
        reg=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if re.match(reg, email): # email 格式正確           
            record=Members.objects.create(name=name,
                                         gender=gender,
                                         birthday=birthday,
                                         email=email,
                                         phone=phone,
                                         address=address)
            record.save()
            return redirect('/myapp1/list_all_records/')
        else:  # email 格式不正確, 綁定原輸入值傳回去
            f=MembersForm({'name': name,
                           'gender': gender,
                           'birthday': birthday,
                           'email': email,
                           'phone': phone,
                           'address': address})             
            message='E-mail 格式不正確'
            return render(request, 'add_record.htm', locals())
    else:   # 來自 list_all_records.htm 的新增紀錄超連結
        message='請輸入資料'
        return render(request, 'add_record.htm', locals())
        
def edit_record(request, id=None, mode=None):
    if mode=='update':  # 來自在 edit_record.htm 按送出
        record=Members.objects.get(id=id)  # id 一定有不須捕捉例外
        record.name=request.POST['name']
        record.gender=request.POST['gender']
        record.birthday=request.POST['birthday']
        record.email=request.POST['email']
        record.phone=request.POST['phone']
        record.address=request.POST['address']
        reg=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if re.match(reg, record.email):        
            record.save()
            return redirect('/myapp1/list_all_records/')
        else: # email 格式不正確, 綁定原輸入值傳回去
            f=MembersForm({'name': record.name,
                           'gender': record.gender,
                           'birthday': record.birthday,
                           'email': record.email,
                           'phone': record.phone,
                           'address': record.address})             
            message='E-mail 格式不正確'
            return render(request, 'edit_record.htm', locals())       
    else: # 來自按 list_all_records.htm 中的編輯超連結:顯示編輯頁面        
        try: # 防止可能來自網址列的 id 不存在
            record=Members.objects.get(id=id)
            # 轉換 birthday 的格式 (因資料表欄位為 date 型態)
            birthday=str(record.birthday)
            birthday=birthday.replace('年', '-')
            birthday=birthday.replace('月', '-')
            birthday=birthday.replace('日', '-')
            # 建立表單物件 (已綁定)
            f=MembersForm({'name': record.name,
                           'gender': record.gender,
                           'birthday': birthday,
                           'email': record.email,
                           'phone': record.phone,
                           'address': record.address}) 
        except:
            message='id 不存在'
        return render(request, 'edit_record.htm', locals())
   
def delete_record(request, id=None):
    if id:  # 有傳入 id 才刪除
        try: # 防止可能來自網址列的 id 不存在
            record=Members.objects.get(id=id)  # 取得紀錄物件
            record.delete()  # 刪除紀錄
        except: # 不處理
            pass
    return redirect('/myapp1/list_all_records/')   
  