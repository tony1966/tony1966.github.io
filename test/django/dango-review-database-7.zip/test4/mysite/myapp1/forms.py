# forms.py of App=myapp1
from django import forms

class MembersForm(forms.Form):
    name=forms.CharField(label='姓名', max_length=20, required=True)
    gender=forms.CharField(label='性別', max_length=2, initial='男')
    birthday=forms.DateField(label='生日', help_text='格式: YY-MM-DD')
    email=forms.CharField(label='信箱', required=True)
    phone=forms.CharField(label='電話', required=True)
    address=forms.CharField(label='地址', max_length=255)