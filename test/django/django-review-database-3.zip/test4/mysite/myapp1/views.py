# views.py of App=myapp1
from django.shortcuts import render, redirect
from myapp1.models import Members

def get_record_by_name(request, name):
    try:
        record=Members.objects.get(name=name)
        type_of_record=type(record)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())

def get_record_by_id(request, id):
    try:
        record=Members.objects.get(id=id)
        type_of_record=type(record)
    except:
        message='讀取失敗'
    return render(request, 'get_record.htm', locals())

def list_all_records(request):
    records=Members.objects.all().order_by('-id')
    return render(request, 'list_all_records.htm', locals())

def add_record(request):
    if request.method=='POST':   # 來自表單提交
        name=request.POST['name']
        gender=request.POST['gender']
        birthday=request.POST['birthday']
        email=request.POST['email']
        phone=request.POST['phone']
        address=request.POST['address']
        record=Members.objects.create(name=name,
                                     gender=gender,
                                     birthday=birthday,
                                     email=email,
                                     phone=phone,
                                     address=address)
        record.save()
        return redirect('/myapp1/list_all_records/')
    else:   # 來自 list_all_records.htm 的新增紀錄超連結
        message='請輸入資料'
        return render(request, 'add_record.htm', locals())
        

